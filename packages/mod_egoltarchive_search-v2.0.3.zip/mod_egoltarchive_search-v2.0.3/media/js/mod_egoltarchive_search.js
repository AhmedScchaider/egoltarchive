jQuery.noConflict();
window.addEvent('domready',function(){
	
});